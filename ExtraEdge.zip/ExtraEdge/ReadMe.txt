Use Below URL to query mobile details

1. SQL queries are available in MobileProductCreate txt file
2. http://{localhost}/api/mobileproduct?fromdate=2021-07-01&todate=2021-07-31
3. Please use your servername instead {myservername}
"ConnectionStrings": {
    "MobileDBConnection": "Server={myservername};Database=Test;Trusted_Connection=True"
  }

