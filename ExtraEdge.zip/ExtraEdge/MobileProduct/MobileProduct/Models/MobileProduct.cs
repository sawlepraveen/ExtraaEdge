﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MobileProduct.Models
{
    public class Mobiles
    {
        public string Brand { get; set; }
        public decimal TotalRetailAmount { get; set; }
        public decimal TotalDiscount { get; set; }
        public decimal TotalSellingAmount { get; set; }
    }
}
