﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using MobileProduct.Models;

namespace MobileProduct.Controllers.Mobile
{
    [Route("api/[controller]")]
    [ApiController]
    public class MobileProductController : ControllerBase
    {
        private AppDbContext adbc;
        public MobileProductController(AppDbContext appDbContext)
        {
            adbc = appDbContext;
        }
        public IEnumerable<Mobiles> GetMobileDetailsByDate(string fromdate,string todate)
        {
            List<Mobiles> productList = new List<Mobiles>();

            productList = adbc.Mobiles.FromSqlRaw("EXECUTE dbo.GetSellDetailByMobileBrand @fromdate,@todate",
                new SqlParameter("@fromdate", fromdate),
                new SqlParameter("@todate", todate)).ToList();

            return productList;
            

        }

        
    }
}
