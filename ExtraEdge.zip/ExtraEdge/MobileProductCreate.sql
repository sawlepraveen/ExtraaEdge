
--create table
-----------------------------
create table MobileProduct(
ID INT PRIMARY KEY IDENTITY(1,1),
Brand nvarchar(50),
Retailprice decimal,
Discount decimal,
SellingPrice decimal,
Unit int,
SellingDate date

)
------------------------------


--Insert query
-------------------------------------------------------------
insert into MobileProduct values('Samsung',10000,1000,9000,1,'2021-07-03')
insert into MobileProduct values('Samsung',10000,1000,9000,1,'2021-07-04')
insert into MobileProduct values('Samsung',10000,1000,9000,1,'2021-07-08')
insert into MobileProduct values('Samsung',10000,1000,9000,1,'2021-07-09')
insert into MobileProduct values('Samsung',10000,1000,9000,1,'2021-07-13')
insert into MobileProduct values('MI',10000,1000,9000,1,'2021-07-14')
insert into MobileProduct values('MI',10000,1000,9000,1,'2021-07-17')
insert into MobileProduct values('MI',10000,1000,9000,1,'2021-07-19')
insert into MobileProduct values('MI',10000,1000,9000,1,'2021-07-20')
insert into MobileProduct values('MI',10000,1000,9000,1,'2021-07-21')
insert into MobileProduct values('NOKIA',10000,1000,9000,1,'2021-07-24')
insert into MobileProduct values('NOKIA',10000,1000,9000,1,'2021-07-26')
insert into MobileProduct values('NOKIA',10000,1000,9000,1,'2021-07-28')
insert into MobileProduct values('NOKIA',10000,1000,9000,1,'2021-07-29')
insert into MobileProduct values('NOKIA',10000,1000,9000,1,'2021-07-30')
---------------------------------------------------------------


--StoredProcedure
--------------------------------------------
create procedure GetSellDetailByMobileBrand
@fromdate date,
@todate  date
as
select mp.Brand,SUM(mp.Retailprice) TotalRetailAmount,SUM(mp.Discount) TotalDiscount, 
SUM(mp.SellingPrice) TotalSellingAmount from MobileProduct mp
where SellingDate between @fromdate and @todate
group by mp.Brand
--------------------------------------------

exec GetSellDetailByMobileBrand @fromdate,@todate
exec GetSellDetailByMobileBrand '2021-07-01','2021-07-30'





